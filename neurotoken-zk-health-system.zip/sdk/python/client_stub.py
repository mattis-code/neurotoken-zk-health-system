class NeuroTokenClient:
    def submit_progress(self,p): return {'status':'received'}
    def verify_proof(self,p): return {'verified':True}