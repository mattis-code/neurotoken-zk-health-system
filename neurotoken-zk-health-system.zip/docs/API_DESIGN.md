# API Design

Draft API structure.