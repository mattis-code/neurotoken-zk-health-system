# ZK Principles

Conceptual notes.