# Data Minimization Policy
NeuroToken ZK Health System™ collects only:
- hashed progress signals
- session metadata
- zero-knowledge proofs

No identifiable data is ever stored.
