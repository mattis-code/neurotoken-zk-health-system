# Compliance & Regulatory Overview  
Aligned with GDPR, EU AI Act (non-high-risk class), ZK minimization principles, and non-clinical classification.
