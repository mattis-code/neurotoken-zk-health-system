#!/bin/bash
echo "Formatting repo..."
