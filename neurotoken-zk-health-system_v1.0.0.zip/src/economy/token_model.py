"""
NeuroToken Token Economy — Python Mock
"""

def compute_bhbr_mock(balance_btc: float):
    return balance_btc * 1000

def compute_bht_issuance_mock(progress_delta: float):
    return progress_delta * 10
