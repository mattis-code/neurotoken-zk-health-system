test("hashing works", () => {
  expect("abc").toBe("abc")
})
