from demo.python.full_demo import run_demo

def test_demo_executes():
    run_demo()
    assert True
