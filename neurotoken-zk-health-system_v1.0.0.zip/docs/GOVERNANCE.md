# Governance Model  
Open governance framework for non-clinical neuro-support.
