# NeuroToken™ Domain Layer

This layer defines:
- Entities
- Validation rules
- Token economy (mock)
- Bridges to ZK engine and SDK

All files are public-safe and contain no sensitive logic.
