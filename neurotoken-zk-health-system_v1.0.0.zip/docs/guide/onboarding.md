# Developer Onboarding

1. Clone repo  
2. Install JS + Python deps  
3. Run tests  
4. Explore the engine  
5. Build integrations  
