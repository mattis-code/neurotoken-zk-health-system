# Developer Guide Overview

This guide provides:
- onboarding
- architecture walkthrough
- engine workflow
- integration patterns
- testing patterns
- contribution workflow
