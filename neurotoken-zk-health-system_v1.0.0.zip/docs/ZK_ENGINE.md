# ZK Engine — Public-Safe Technical Overview
Explains high-level algorithm steps for progress-proof generation without revealing proprietary circuits.
