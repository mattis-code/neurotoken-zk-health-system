# ZK Orchestrator — Overview

The orchestrator coordinates:
- serialization
- hashing
- proof envelope generation
- domain → ZK bridging
- multi-language output parity

All logic is public-safe.
