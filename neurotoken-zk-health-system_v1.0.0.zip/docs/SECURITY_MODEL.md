# Security Model  
Threat model, hashing, commitment scheme explanation, digital signing and anti-tamper architecture.
